#include "parser.h"

int main() {
    return start_compiler("stdin", "stdout");
}